<?php
/* =============================================================
   api/categorias.php — CRUD para tbl_categorias
   Columnas: id_categoria, nombre, descripcion
============================================================= */
header('Content-Type: application/json');
require_once __DIR__ . '/../configuracion/cors.php';

require_once '../configuracion/Conexion.php';
require_once '../configuracion/auth.php';
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'GET' && $method !== 'OPTIONS') {
    verificarTokenAdmin($pdo);
}

/* ── Auto-seed: asegurar que las 4 colecciones base existan ── */
try {
    $count = $pdo->query("SELECT COUNT(*) FROM tbl_categorias")->fetchColumn();
    if ((int)$count === 0) {
        $seed = [
            ['Nicho',      'Perfumería de autor: las casas de nicho más exclusivas'],
            ['Oriental',   'Oud, Ámbar, Sándalo y Musk en su máxima expresión'],
            ['Diseñador',  'Las grandes maisons y firmas reconocidas a nivel mundial'],
            ['Exclusivos', 'Ediciones especiales y fragancias únicas de colección'],
        ];
        $ins = $pdo->prepare("INSERT INTO tbl_categorias (nombre, descripcion) VALUES (:n, :d)");
        foreach ($seed as [$n, $d]) {
            $ins->execute([':n' => $n, ':d' => $d]);
        }
    }
} catch (PDOException $e) { /* continuar */ }

try {
    switch ($method) {
        case 'GET':
            $id = $_GET['id'] ?? null;
            if ($id) {
                $s = $pdo->prepare("SELECT * FROM tbl_categorias WHERE id_categoria = :id");
                $s->execute([':id' => $id]);
                echo json_encode(['ok' => true, 'data' => $s->fetch()]);
            } else {
                $s = $pdo->query("SELECT * FROM tbl_categorias ORDER BY nombre");
                echo json_encode(['ok' => true, 'data' => $s->fetchAll()]);
            }
            break;

        case 'POST':
            $b = json_decode(file_get_contents('php://input'), true);
            if (empty($b['nombre'])) { echo json_encode(['ok'=>false,'mensaje'=>'Nombre requerido']); exit; }
            $s = $pdo->prepare("INSERT INTO tbl_categorias (nombre, descripcion) VALUES (:nombre, :descripcion)");
            $s->execute([':nombre' => $b['nombre'], ':descripcion' => $b['descripcion'] ?? '']);
            echo json_encode(['ok' => true, 'mensaje' => 'Categoría creada', 'id' => $pdo->lastInsertId()]);
            break;

        case 'PUT':
            $b = json_decode(file_get_contents('php://input'), true);
            if (empty($b['id_categoria'])) { echo json_encode(['ok'=>false,'mensaje'=>'ID requerido']); exit; }
            $s = $pdo->prepare("UPDATE tbl_categorias SET nombre=:nombre, descripcion=:descripcion WHERE id_categoria=:id");
            $s->execute([':nombre' => $b['nombre'], ':descripcion' => $b['descripcion'] ?? '', ':id' => $b['id_categoria']]);
            echo json_encode(['ok' => true, 'mensaje' => 'Categoría actualizada']);
            break;

        case 'DELETE':
            $id = $_GET['id'] ?? null;
            if (!$id) { echo json_encode(['ok'=>false,'mensaje'=>'ID requerido']); exit; }
            $pdo->prepare("DELETE FROM tbl_categorias WHERE id_categoria = :id")->execute([':id' => $id]);
            echo json_encode(['ok' => true, 'mensaje' => 'Categoría eliminada']);
            break;

        default:
            http_response_code(405);
            echo json_encode(['ok' => false, 'mensaje' => 'Método no permitido']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'mensaje' => $e->getMessage()]);
}
require_once '../configuracion/CerrarConexion.php';
?>